<?php
/*
 * author: simon poppe
 */

$firstName = 'simon';       // mijn voornaam
$lastName = 'poppe';        // mijn achternaam

echo 'Hello World' . PHP_EOL;       // hello world afprinten
echo 'It\'s raining outside' . PHP_EOL;     // it's raining outside afprinten
echo 'The value of $firstName is ' . $firstName . '. The value of $lastName is ' . $lastName . '.' . PHP_EOL;  // voornaam en achternaam afprinten
?>
